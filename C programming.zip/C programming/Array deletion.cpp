#include <stdio.h>
//Print function
print(int a[],int n){
	int i;
	for(i=0;i<n;i++)
{
	printf("\n%d\n",a[i]);
}
}
int main()
{
	int a[20],i,n,index,new1;
	printf("\nEnter the size of the array\n");
	scanf("%d\n",&n);
	printf("\nEnter elements in array\n");
	for(i=0;i<n;i++)
	{
		scanf("\n%d\n",&a[i]);
	}
	printf("\nEnter position should not be greater than %d\n",n);
	scanf("\n%d\n",&index);
	if(index<=n && index>0)
	{
		printf("\nBefore deletion");
		print(a,n);
		for(i=index-1;i<n-1;i++){
			a[i]=a[i+1];
		}
	
	printf("\nAfter deletion ");
	print(a,n-1);
}
else
printf("\nInvalid input");
return 0;
}
