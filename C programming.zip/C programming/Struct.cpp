#include<stdio.h>
//Written by Ayush Kumar
struct student
{
    int rollno;
    char deptartment_code[25];
    float Cgpa;
};
int main()
{
    struct student classes[5],t;
    int j,k,n;
    printf("Enter the number of students\n");
    scanf("%d",&n);
    for(k=0;k<n;k++)
    {
        printf("Enter rollno dept code and Cgpa for %dst student\ :",k+1);
        scanf("%d%s%f",&classes[k].rollno,&classes[k].deptartment_code,&classes[k].Cgpa);
    }
    for(j=0;j<n-1;j++)
    {
        for(k=j+1;k<n;k++)
        {
            if(classes[j].rollno>classes[k].rollno)
            {
                t=classes[j];
                classes[j]=classes[k];
                classes[k]=t;
            }
        }
    }
    printf("Printing the records\n");
    for(j=0;j<n;j++)
    {
        printf("Details for Student %d\n",j+1);
        printf("%d \n%s \n%f\n",classes[j].rollno,classes[j].deptartment_code,classes[j].Cgpa);
    }
}
