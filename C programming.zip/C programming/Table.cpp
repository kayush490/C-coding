#include <stdio.h>
int main(){
	int x;
	printf("Determine the storage value for your array\n");
	scanf("%d",&x);
	int arr[x],a,p;
	printf("Enter the number for which you want to see table :\n");
	scanf("%d",&a);
	printf("Enter upto what extend you want to see ,multiplication :\n");
	scanf("%d",&p);
	for(int i=0;i<p;i++){
		arr[i]= a*(i+1);
	}
	for (int i=0;i<p;i++){
		printf("The multiplication of %d x %d = %d\n",a,(i+1),arr[i]);
	}
return 0;
}

