#include <stdio.h>
void pattern(int a);
//Printing of pattern 
//*
//**
//***
int main(){
	int a;
	printf("Enter the no. of row : \n");
	scanf("%d",&a);
	printf("-----The given star pattern is-----\n");
	pattern(a);
	return 0;
}
//Solving Recurrsively.
//Defining Function.
void pattern(int a){
	if(a==1){
		printf("-\n");
		return;
	}
	pattern(a-1);
	for(int i=0;i<(2*a-1);i++){
		printf("-");
	}
	printf("\n");
}
