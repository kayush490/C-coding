//Writing a program to covert celcius into fahrenheit
#include <stdio.h>
float fahrenheit_of(float celsius );//Prototype
int main(){
	float cel;
	printf("\t\t\tWELCOME TO FAHRENHEIT COVERTOR MADE BY AYUSH\t\t\t\n\n\n");
	printf("--------Enter celsius in degree to covert into fahrenheit---------- : \n");
	scanf("%f",&cel);
	printf("The coverted temperature scale is %f F \n",fahrenheit_of(cel));
}

//Defining our function 
float fahrenheit_of(float celcius){
	float fahrenheit;
	fahrenheit = ((celcius*9)/5)+32;
	return fahrenheit;
}

