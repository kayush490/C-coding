#include <stdio.h>
void ten(int *a);
int main(){
	int b=4;
	printf("The original value of b is 4\n");
	printf("The ten times value of b is \n");
	ten(&b);
	return 0;
	}
	
	void ten(int *a){
		int temp,c;
		temp = *a;
		c = temp*10;
		printf("%d",c);
		
	}

