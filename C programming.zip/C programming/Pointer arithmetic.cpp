#include <stdio.h>
int main(){
	int c;
	int arr[4]={1,4,5,8};
	int *ptr;
	int *pmt;
	ptr = &arr[0];
	pmt = &arr[1];
	//Addition of pointer
	//printf("The address of pointer is %d\n",ptr);
	//ptr++;
	//printf("The address of pointer is %d\n",ptr);
	//ptr--;
	//ptr--;
	//ptr--;
	//printf("The address of pointer is %d\n",ptr);
	//printf("The address of pointer is %d\n",(ptr++)-(ptr));
	c = pmt-ptr;
	printf("The diffrence of address of pointer is %d\n",c);
	return 0;
}
