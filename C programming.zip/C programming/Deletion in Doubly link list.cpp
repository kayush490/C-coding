#include <stdio.h>
#include <stdlib.h>
//Written by Ayush Kumar
struct node {
    int number;
    struct node * preptr;
    struct node * nextptr;
}*startnode, *endnode;
 

void DlListcreation(int n);
void DlListDeleteFirstNode();
void displayDlList(int a);

int main()
{
    int n,num1,a;
    ...........
    startnode = NULL;
    endnode = NULL;
	printf("\n\n Doubly Linked List : Delete node from the beginning of a doubly linked list :\n");
	printf("----------------------------------------------------------------------------------\n");	   	
    printf(" Input the number of nodes (3 or more ): ");
    scanf("%d", &n);
    DlListcreation(n); 
    a=1;
    displayDlList(a);
    DlListDeleteFirstNode();
        a=2;
    displayDlList(a);
    return 0;
}
 
void DlListcreation(int n)
{
    int i, number;
    struct node *fnNode;
 
    if(n >= 1)
    {
        startnode = (struct node *)malloc(sizeof(struct node));
        if(startnode != NULL)
        {
            printf(" Input data for node 1 : "); // assigning data in the first node
            scanf("%d", &number);
            startnode->number = number;
            startnode->preptr = NULL;
            startnode->nextptr = NULL;
            endnode = startnode;
            for(i=2; i<=n; i++)
            {
                fnNode = (struct node *)malloc(sizeof(struct node));
                if(fnNode != NULL)
                {
                    printf(" Input data for node %d : ", i);
                    scanf("%d", &number);
                    fnNode->number = number;
                    fnNode->preptr = endnode;    // new node is linking with the previous node
                    fnNode->nextptr = NULL;     // set next address of fnnode is NULL
                    endnode->nextptr = fnNode;   // previous node is linking with the new node
                    endnode = fnNode;            // assign new node as last node
                }
                else
                {
                    printf(" Memory can not be allocated.");
                    break;
                }
            }
        }
        else
        {
            printf(" Memory can not be allocated.");
        }
    }
}

void DlListDeleteFirstNode()
{
    struct node * NodeToDel;
    if(startnode == NULL)
    {
        printf(" Delete is not possible. No data in the list.\n");
    }
    else
    {
        NodeToDel = startnode;
        startnode = startnode->nextptr;   // move the next address of starting node to 2 node
        startnode->preptr = NULL;      // set previous address of staring node is NULL
        free(NodeToDel);            // delete the first node from memory
    }
}

void displayDlList(int m)
{
    struct node * tmp;
    int n = 1;
    if(startnode == NULL)
    {
        printf(" No data found in the List yet.");
    }
    else
    {
        tmp = startnode;
        if (m==1)
        {
        printf("\n Data entered in the list are :\n");
        }
        else
        {
         printf("\n After deletion the new list are :\n");   
        }
        while(tmp != NULL)
        {
            printf(" node %d : %d\n", n, tmp->number);
            n++;
            tmp = tmp->nextptr; // current pointer moves to the next node
        }
    }
}
