#include <stdio.h>
#include <stdlib.h>
struct node{
	int data;
	struct node *next;
};
void linklisttraversal(struct node *ptr){
	while(ptr!= NULL){
	printf("Element : %d\n",ptr->data);
	ptr = ptr->next;
}
}
//struct node *deletion(struct node *head){ //Function for deleting first node.
//	struct node *ptr;
//	ptr=head;
//	head=head->next;
//	free(ptr);
//	return head;
//}
struct node *del(struct node *head,int index){ //Function to delete node at given index.
	struct node *p = head;
	struct node *q = head->next;
	for(int i=0;i<(index-1);i++){
		p=p->next;
		q=q->next;
	}
	p->next = q->next;
	free(q);
	return head;
}
int main(){
	struct node *head;
	struct node *second;
	struct node *third;
	// Allocate in heap
	head = (struct node*)malloc(sizeof(struct node));
	second = (struct node*)malloc(sizeof(struct node));
	third = (struct node*)malloc(sizeof(struct node));
	// Linking the nodes
	head->data = 12;
	head->next = second;
	second->data = 14;
	second->next = third;
	third->data = 20;
	third->next = NULL;
	linklisttraversal(head);
	head = del(head,2);
	printf("\n");
	linklisttraversal(head);
	return 0;
}
