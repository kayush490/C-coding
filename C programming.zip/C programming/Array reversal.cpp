// Iterative C program to reverse an array
#include<stdio.h>
//Written by Ayush Kumar
/* Function to reverse arr[] from start to end*/
void revArray(int array[], int start, int end)
{
	int temporary;
	while (start < end)
	{
		temporary = array[start];
		array[start] = array[end];
		array[end] = temporary;
		start++;
		end--;
	}
}	

/* Function that prints out an array on a line */
void printArray(int arr[], int size)
{
int i;
for (i=0; i < size; i++)
	printf("%d ", arr[i]);

printf("\n");
}

/* Driver function to execute above functions */
int main()
{
	int arr[] = {11, 82, 13, 24, 45, 16};
	int n = sizeof(arr) / sizeof(arr[0]);
	printf("Original array is\n");
	printArray(arr, n);
	revArray(arr, 0, n-1);
	printf("\nReversed array is \n");
	printArray(arr, n);
	return 0;
}

