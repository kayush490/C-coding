#include<stdio.h>
int main(){
   int Arr[50],Position,i,size,key;
   printf("Enter no of elements in array:");
   scanf("%d",&size);
   printf("Enter %d elements are:\n",size);
   for(i=0;i<size;i++)
      scanf("%d",&Arr[i]);
   printf("Enter the Position where you want to insert the element:");
   scanf("%d",&Position);
   printf("Enter the key into that Position:");
   scanf("%d",&key);
   for(i=size-1;i>=Position-1;i--)
      Arr[i+1]=Arr[i];
   Arr[Position-1]= key;
   printf("Final array after inserting the key is\n");
   for(i=0;i<=size;i++)
      printf("%d\n",Arr[i]);
   return 0;
}
