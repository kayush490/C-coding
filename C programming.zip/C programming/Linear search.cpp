#include<stdio.h>
//Written by Ayush Kumar
//Linear Search
 int main()
{
    int Ar[30],i,X,n;
    printf("ENTER NUMBER OF ELEMENTS:");
    scanf("%d",&n);
    printf("ENTER ARRAY ELEMENTS\n");
    for(i=0;i<n;++i)
        scanf("%d",&Ar[i]);
    printf("ENTER THE ELEMENT TO BE SEARCHED:\n");
    scanf("%d",&X);
    for(i=0;i<n;++i)
    
         if(Ar[i]==X)
            break;
    if(i<n)
        printf("ELEMENT FOUND AT INDEX %d",i);
    else
        printf("ELEMENT NOT FOUND");
}
