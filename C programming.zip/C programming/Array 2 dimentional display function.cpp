#include <stdio.h>
void display(int n,int m);
int main(){
	int arr[3][3];
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			printf("Enter the marks of %d student in %d subject\n",i+1,j+1);
			scanf("%d",&arr[i][j]);
		}
		
}
display(3,3);
	return 0;
}
void display(int n,int m){
	int *arr[n][m];
	for (int i=0;i<n;i++){
		for (int j=0;j<m;j++){
		printf("%d\t",*arr[i][j]);
	}
	printf("\n");
}
}

