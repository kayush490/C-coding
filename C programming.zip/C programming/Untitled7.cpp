#include <stdio.h>
int main()
{
	float n
	do{
	printf("Enter a number to check , it is prime or not : /t");
	scanf("%f",&n);
}
while(typeof(n)=int){
	if(typeof(n)=int && n>=0) {
		printf("You entered a valid positve integer");
	}
	else{
		printf("Please enter valid integer");
	}
}
}
return 0;
}
