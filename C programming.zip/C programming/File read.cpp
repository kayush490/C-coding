#include <stdio.h>
int main(){
	int a,b,c;
	FILE *ptr;
	ptr = fopen("number.txt","r");
	fscanf(ptr,"%d %d %d",&a,&b,&c);
	printf("The given numbers are %d %d %d",a,b,c);
	fclose(ptr);
	return 0;	
}
