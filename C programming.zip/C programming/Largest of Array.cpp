#include <stdio.h>
//Written by Ayush Kumar
int main() {
  int num;
  double ar[100];
  printf("Enter the number of elements (1 to 100): ");
  scanf("%d", &num);

  for (int i = 0; i < num; ++i) {
    printf("Enter number%d: ", i + 1);
    scanf("%lf", &ar[i]);
  }

  // Storing the largest number to ar[0]
  for (int i = 1; i < num; ++i) {
    if (ar[0] < ar[i]) {
      ar[0] = ar[i];
    }
  }

  printf("Largest element = %.2lf", ar[0]);

  return 0;
}
