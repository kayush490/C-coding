#include<stdio.h>
void display(int m,int n,int A[m][n])
{
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");
    }
}
void sum(int m,int n,int A[m][n],int B[m][n])
{
    int C[m][n];
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            C[i][j]=A[i][j]+B[i][j];
            printf("%d ",C[i][j]);
        }
        printf("\n");
    }
}
void sub(int m,int n,int A[m][n],int B[m][n])
{
    int C[m][n];
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            C[i][j]=A[i][j]-B[i][j];
            printf("%d ",C[i][j]);
        }
        printf("\n");
    }
}
void prod(int m,int n,int o,int p,int A[m][n],int B[o][p])
{
    int i,j,C[m][p];
    for(i=0;i<m;i++)
    {
        for(j=0;j<p;j++)
        {
            C[i][j]=0;
            for(int k=0;k<n;k++)
            {
                C[i][j]+=A[i][k]*B[k][j];
            }
        }
    }
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("%d ",C[i][j]);
        }
        printf("\n");
    }
}
void transpose(int m,int n,int A[m][n])
{
    int i,j;    
    for(i=0;i<n;i++)    
    {
        for(j=0;j<m;j++)
        {
            printf("%d ",A[j][i]);
        }
        printf("\n");    
    }
}

int main()
{
    int i,j,m,n,o,p;
    printf("Enter the no. of rows for Matrice 1 : ");
    scanf("%d",&m);
    printf("Enter the no. of columns for Matrice 1 : ");
    scanf("%d",&n);
    printf("Enter the no. of rows for Matrice 2 : ");
    scanf("%d",&o);
    printf("Enter the no. of columns for Matrice 2 : ");
    scanf("%d",&p);
    int A[m][n],B[o][p];
    printf("Enter Matrice 1 : ");
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&A[i][j]);
        }
    }
    printf("Enter Matrice 2 : ");
    for(i=0;i<o;i++)
    {
        for(j=0;j<p;j++)
        {
            scanf("%d",&B[i][j]);
        }
    }
    printf("Matrice 1 is :\n");
    display(m,n,A);
    printf("Matrice 2 is :\n");
    display(o,p,B);
    if(m==o&&n==p)
    {
        printf("Sum of Matrices is :\n");
        sum(m,n,A,B);
    }
    else
    {
        printf("Addition of Matrices is not possible.");
    }
    if(m==o&&n==p)
    {
        printf("Difference of Matrices is :\n");
        sub(m,n,A,B);
    }
    else
    {
        printf("Subtraction of Matrices is not possible.");
    }
    if(n!=o)
    {
        printf("Multiplication of Matrices is not possible");
    }
    else
    {
        printf("Product of Matrices is :\n");
        prod(m,n,o,p,A,B);
    }
    printf("Transpose of Matrice 1 is :\n");
    transpose(m,n,A);
}

