#include <stdio.h>
//Written by Ayush Kumar
//Display Function
void display(int arr[],int n){ //Writing display function.
	for(int i=0;i<n;i++){
		printf("%d\t",arr[i]);
	}
	printf("\n");
}
void inddeletion(int arr[],int size,int index){
	for (int i=index;i<size;i++){
		arr[i]=arr[i+1];
	}
}
int main(){
	int arr[100]={83,91,74,25,35,65};
	int size = 6, index=2;
	display(arr,6);
	inddeletion(arr,6,2);
	size-=1;
	display(arr,5);
	return 0;
}
