#include <stdio.h>
int  main(){
	int a;
	int arr[10];
	FILE *ptr;
	ptr = fopen("multiplication.txt","w");
	printf("Enter the number to show multiplication : \n");
	scanf("%d",&a);
	for (int i=0;i<10;i++){
		arr[i] = a*(i+1);
		printf("The multiplication of %d * %d is %d\n",a,i+1,arr[i]);
		fprintf(ptr , "The multiplication of %d * %d is %d\n",a,i+1,arr[i]);
	}
	return 0;
}
