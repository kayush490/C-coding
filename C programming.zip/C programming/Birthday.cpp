#include <stdio.h>
#include <string.h>
struct birthdaybash{
	char name[20];
    int age;
    char wish[500];
};

int main(){
	struct birthdaybash girl;
	printf("\t\t\t------{***[WISHES FROM MY SIDE]***}-------\t\t\n\n");
	printf("\t\t[****KINDLY  ENTER  YOUR  FULL NAME  BIRTHDAY  GIRL****]\t\t\t\n");
	gets(girl.name);
	printf("\n\n\t\t[****KINDLY  ENTER  YOUR  AGE , YOU ARE GOING TO BE ,  BIRTHDAY  GIRL****]\t\t\n\n");
	scanf("%d",&girl.age);
	printf("\n\n\nHey %s ! ,\nIt is great day for you,\nI am wishing you a very happy birthday dear,on turning %d.\nKeep enjoying ,Keep succeeding, Keep smiling ",girl.name,girl.age);
	strcpy(girl.wish,"Happy Birthday to you  |  Happy Birthday to You  | Happy Birthday Dear Siddhi. | Happy Birthday to You. | From good friends and true, | From old friends and new, | May good luck go with you, | And happiness too.");
	printf("\n\n\n\t\t\tHERE IS BIRTHDAY SONG FROM MY SIDE\t\t\t\n%s",girl.wish);
	printf("\n\n\t\t\t\t***/WISHES BY AYUSH KUMAR/***\t\t\t");
	return 0;
}

