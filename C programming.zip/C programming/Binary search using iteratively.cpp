#include <stdio.h>
//Written by Ayush Kumar
// A iterative binary search function. It returns location of X in
// given array Array[l..u] if present, otherwise -1
int binarySearch(int Array[], int l, int u, int X)
{
while (l <= u)
{
	int m = l + (u-l)/2;

	// Check if X is present at middle
	if (Array[m] == X)
		return m;

	// If X greater, ignore left half
	if (Array[m] < X)
		l = m + 1;

	// If X is smaller, ignore right half
	else
		u = m - 1;
}

// if we reach here, then element was not present
return -1;
}

int main(void)
{
int Array[] = {21, 37, 4, 10, 49};
int n = sizeof(Array)/ sizeof(Array[0]);
int X = 10;
int result = binarySearch(Array, 0, n-1, X);
(result == -1)? printf("Element is not present in array")
				: printf("Element is present at index %d", result);
return 0;
}

