// C program to traverse the array
//Written by Ayush Kumar
#include <stdio.h>

// Function to traverse and print the array
void printArray(int* arr, int n)
{
	int i;

	printf("\nArray: ");
	for (i = 0; i < n; i++) {
		printf("%d ", arr[i]);
	}
	printf("\n");
}

// Driver program
int main()
{
	int B[] = { 2, -1, 5, 6, 0, -3,  41,  13 };
	int n = sizeof(B) / sizeof(B[0]);
printf("Traversal of array :");
	printArray(&B[0], n);

	return 0;
}

