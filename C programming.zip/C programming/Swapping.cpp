// Swapping Program
#include <stdio.h>
void swap(int *a,int *b);

int main(){
	int x=3,y=4;
	printf("Enter the value of x is 3:\n");
	//scanf("%d",x);
	printf("Enter the value of y is 4:\n");
	//scanf("%d",y);
	// Now Swapping
	swap(&x,&y);
	printf("The swapped value of x is %d and y is %d",x,y);
	return 0;
}

void swap(int *a,int *b){
	int temp;
	temp = *a;
	*a = *b;
	*b = temp;	
}
