#include <stdio.h>
void GA(); //Prototype of function.
void GM();
void GN();
int main(){
	printf("********CALLING OUT FUNCTION********\n");
	GM();
	GA();
	GN();
	return 0;
}

void GM(){
	printf("Hello sir, GOOD MORNING\n");   // Defining a function
}
void GA(){
	printf("Hello sir, GOOD AFTERNOON\n");
}
void GN(){
	printf("Hello sir, GOOD NIGHT\n");
}

