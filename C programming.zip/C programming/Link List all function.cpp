#include <stdio.h>
#include <stdlib.h>
//Written by Ayush Kumar
struct node
{

    int data;
    struct node *next;
};

struct node *head;

void crtList(int n);

void insrtNode_End(int data);

void showlist();

void searchingEle(int data);

void deleteNode(int data_del);

int main()

{

    int n, data;

    printf("Enter the total number of nodes to be in link list: ");

    scanf("%d", &n);

    crtList(n);

    printf("\nData in the list \n");

    showlist();

    int data_new;

    printf("Enter data for new node:");

    scanf("%d", &data_new);

    insrtNode_End(data_new);

    showlist();
    int search;
    printf("\nEnter the element to be searched:");
    scanf("%d", &search);
    searchingEle(search);
    printf("\nEnter the element to be deleted:");
    int del_data;
    scanf("%d", &del_data);
    deleteNode(del_data);
    showlist();

    return 0;
}

void crtList(int n)

{

    struct node *newNode, *current;

    int data, i;

    head = (struct node *)malloc(sizeof(struct node));

    if (head == NULL)

    {

        printf("Unable to allocate memory.");
    }

    else

    {

        printf("Enter the data of node 1: ");

        scanf("%d", &data);

        head->data = data;

        head->next = NULL;

        current = head;

        for (i = 2; i <= n; i++)

        {

            newNode = (struct node *)malloc(sizeof(struct node));

            if (newNode == NULL)

            {

                printf("Unable to allocate memory.");

                break;
            }

            else

            {

                printf("Enter the data of node %d: ", i);

                scanf("%d", &data);

                newNode->data = data;
                newNode->next = NULL;
                current->next = newNode;
                current = current->next;
            }
        }

        printf("SINGLY LINKED LIST CREATED SUCCESSFULLY\n");
    }
}

void showlist()
{
    struct node *current;
    current = head;
    while (current != NULL)
    {
        printf("%d\n", current->data);
        current = current->next;
    }
}

void insrtNode_End(int data_new)
{
    struct node *current, *new_node;
    new_node = (struct node *)malloc(sizeof(struct node));
    current = head;
    while (current->next != NULL)
    {
        current = current->next;
    }
    new_node->data = data_new;
    new_node->next = NULL;
    current->next = new_node;
}

void deleteNode(int data_del)
{
    struct node *current, *del;
    current = head;
    int flag = 0;
    if (head == NULL)
    {
        printf("List is empty\n");
        return;
    }
    else
    {
        while (current->next != NULL)
        {
            if (current->next->data == data_del)
            {
                flag = 1;
                break;
            }
            current = current->next;
        }
        if (flag == 0)
        {
            printf("\nDeletion element not found in list\n");
            return;
        }
        else
        {
            del = current->next;
            current->next = del->next;
            del->next = NULL;
            free(del);
            printf("Node with value %d deleted successfully\n", data_del);
        }
    }
}
void searchingEle(int data)
{
    struct node *current, *del;
    current = head;
    int flag = 0;
    if (head == NULL)
    {
        printf("List is empty\n");
        return;
    }
    else
    {
        while (current->next != NULL)
        {
            if (current->next->data == data)
            {
                flag = 1;
                break;
            }
            current = current->next;
        }
        if (flag == 0)
        {
            printf("\nSearch element not found in list\n");
            return;
        }
        else
        {
            printf("%d is present in the list", data);
        }
    }
}

