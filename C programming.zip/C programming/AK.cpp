#include <stdio.h>
#define MAX_SIZE 100
//Written by Ayush Kumar
//Function to insert an element in an array.
//arr[] = array, elements = number of elements present in the array
//key = element to be inserted in the array
// size of the array
int insertElement(int arr[], int elements, int key, int size) 
{ 
// Check if the capacity of the array is already full 
if (elements >= size) 
return elements; 
//If not then the element is inserted at the last index 
//and the new array size is returned
arr[elements] = key; 
return (elements + 1); 
}
void read(int arr[MAX_SIZE],int size){
	for(int i=0;i<size;i++){
		printf("The value of %d element of array is %d\n",i+1,arr[i]);
	}
}
void display(int arr[MAX_SIZE],int index){//Display of specific element
printf("The element at index %d is %d",index,arr[index]);
}
int main()
{
	int A[MAX_SIZE],size;
	printf("Enter the size of array you want to make :\n");
	scanf("%d",&size);
	insertElement(A,0,45,size);
	insertElement(A,1,13,size);
	insertElement(A,2,16,size);
	insertElement(A,3,17,size);
	read(A,size);
	display(A,2);
	return 0;
}
