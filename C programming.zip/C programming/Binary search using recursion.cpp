// C program to implement recursive Binary Search
//Written by Ayush Kumar
#include <stdio.h>

// A recursive binary search function. It returns
// location of X in given array array[l..R] is present,
// otherwise -1
int binarySearch(int array[], int l, int R, int X)
{
	if (R >= l) {
		int middle = l + (R - l) / 2;

		// If the element is present at the middle
		// itself
		if (array[middle] == X)
			return middle;

		// If element is smaller than middle, then
		// it can only be present in left subarray
		if (array[middle] > X)
			return binarySearch(array, l, middle - 1, X);

		// Else the element can only be present
		// in right subarray
		return binarySearch(array, middle + 1, R, X);
	}

	// We reach here when element is not
	// present in array
	return -1;
}

int main(void)
{
	int array[] = { 27, 31, 4, 10, 48 };
	int n = sizeof(array) / sizeof(array[0]);
	int X = 4;
	int result = binarySearch(array, 0, n - 1, X);
	(result == -1) ? printf("Element is not present in array")
				: printf("Element is present at index %d",
							result);
	return 0;
}

